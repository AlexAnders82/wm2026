# ClipScope AI Bundle

Dieses Archiv ist fuer KI-Lesbarkeit optimiert.

- `page.md`: bereinigter Seitentext mit Bild- und Videohinweisen.
- `page.html`: bereinigtes HTML ohne Skripte.
- `metadata.json`: strukturierte Metadaten, Asset-Status und Quellen.
- `assets/`: Bilder und Stylesheets, sofern Chrome den Zugriff erlaubt hat.
- `viewport.webp`: kompakter Screenshot des sichtbaren Bereichs.

Quelle: https://wm2026.com.de/spielplan
Erfasst: 2026-06-21T21:01:41.405Z