# WM 2026 Spielplan — alle 104 Spiele in deutscher Zeit

- URL: https://wm2026.com.de/spielplan
- Captured: 2026-06-21T21:01:41.379Z
- Description: Alle Spiele der WM 2026 Tag für Tag: kompletter Spielplan, Anstoßzeiten in deutscher Zeit (MESZ), Stadien, Gruppen und Mannschaften. 104 Spiele von der Gruppenphase bis zum Finale.

## Neuseeland vs Ägypten

### Kompletter Spielplan der WM 2026

### Kommende Spiele

### Letzte Ergebnisse

#### Frühstück mit der WM

## Page Text

· 48 Teams · 12 Gruppen · 104 Spiele

Berichterstattung zu allen 104 Spielen der FIFA WM 2026, mit Spielplan Tag für Tag in deutscher Zeit (MESZ), kompletten Spieldetails und Live-Begleitung während des Turniers. Deutschland findest du unter /mannschaft; alle Anstoßzeiten in deutscher Zeit unter /spielzeiten; die TV-Übertragung unter /tv-uebertragung.

Wir verwenden keine Tracking-Cookies und geben keine Daten an Dritte weiter. Nur technische Speicherung für Einstellungen (Dark Mode, Favoriten). Anonyme Analytics über Cloudflare.

Installiere WM26 auf dem Handy

Sofortiger Zugriff, ohne Browser und mit Tor-Benachrichtigungen.

Tägliche Zusammenfassung um 7:00 Uhr: die Spiele des Tages, das letzte Ergebnis, ein redaktioneller Beitrag. Kein Spam, kein Griff zum Handy mitten in der Arbeit.

Abbestellen mit einem Klick. Wir geben deine E-Mail an niemanden weiter.

Erhalten. Prüfe deine E-Mails zur Bestätigung.

Berichterstattung zur WM 2026 in anderen Märkten

🇵🇹 Portugal mundial2026.com.pt →

🇪🇸 España copamundialdefutbol.es →

🇵🇪 Perú mundial2026.pe →

Unabhängige Berichterstattung zur FIFA WM 2026. Spielplan, Tabellen, Profile und taktische Analysen.

© 2026 WM26. Unabhängiges redaktionelles Projekt.

## Images

- Offizielles WM-2026-Emblem: assets/images/001-offizielles-wm-2026-emblem.svg
- Flagge nz: assets/images/002-flagge-nz.png
- Flagge eg: assets/images/003-flagge-eg.png
- MagentaTV: assets/images/004-magentatv.svg
- Flagge ar: assets/images/005-flagge-ar.png
- Flagge at: assets/images/006-flagge-at.png
- Flagge fr: assets/images/007-flagge-fr.png
- Flagge iq: assets/images/008-flagge-iq.png
- Flagge no: assets/images/009-flagge-no.png
- Flagge sn: assets/images/010-flagge-sn.png
- Flagge jo: assets/images/011-flagge-jo.png
- Flagge dz: assets/images/012-flagge-dz.png
- Flagge pt: assets/images/013-flagge-pt.png
- Flagge uz: assets/images/014-flagge-uz.png
- Flagge gb-eng: assets/images/015-flagge-gb-eng.png
- Flagge gh: assets/images/016-flagge-gh.png
- Flagge pa: assets/images/017-flagge-pa.png
- Flagge hr: assets/images/018-flagge-hr.png
- Flagge co: assets/images/019-flagge-co.png
- Flagge cd: assets/images/020-flagge-cd.png
- Flagge ba: assets/images/021-flagge-ba.png
- Flagge qa: assets/images/022-flagge-qa.png
- Flagge ch: assets/images/023-flagge-ch.png
- Flagge ca: assets/images/024-flagge-ca.png
- Flagge ma: assets/images/025-flagge-ma.png
- Flagge ht: assets/images/026-flagge-ht.png
- Flagge gb-sct: assets/images/027-flagge-gb-sct.png
- Flagge br: assets/images/028-flagge-br.png
- Flagge cz: assets/images/029-flagge-cz.png
- Flagge mx: assets/images/030-flagge-mx.png
- Flagge za: assets/images/031-flagge-za.png
- Flagge kr: assets/images/032-flagge-kr.png
- Flagge ec: assets/images/033-flagge-ec.png
- Flagge de: assets/images/034-flagge-de.png
- ARD/ZDF: assets/images/035-ard-zdf.svg
- Flagge cw: assets/images/036-flagge-cw.png
- Flagge ci: assets/images/037-flagge-ci.png
- Flagge jp: assets/images/038-flagge-jp.png
- Flagge se: assets/images/039-flagge-se.png
- Flagge tn: assets/images/040-flagge-tn.png
- Flagge nl: assets/images/041-flagge-nl.png
- Flagge py: assets/images/042-flagge-py.png
- Flagge au: assets/images/043-flagge-au.png
- Flagge tr: assets/images/044-flagge-tr.png
- Flagge us: assets/images/045-flagge-us.png
- Flagge uy: assets/images/046-flagge-uy.png
- Flagge es: assets/images/047-flagge-es.png
- Flagge cv: assets/images/048-flagge-cv.png
- Flagge sa: assets/images/049-flagge-sa.png
- Flagge ir: assets/images/050-flagge-ir.png
- Flagge be: assets/images/051-flagge-be.png
- Flagge xx: assets/images/052-flagge-xx.svg
- Open Graph image: assets/images/057-open-graph-image.bin