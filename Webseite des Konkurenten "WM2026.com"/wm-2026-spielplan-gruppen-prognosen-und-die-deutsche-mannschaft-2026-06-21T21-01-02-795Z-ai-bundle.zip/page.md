# WM 2026 — Spielplan, Gruppen, Prognosen und die deutsche Mannschaft

- URL: https://wm2026.com.de/
- Captured: 2026-06-21T21:00:59.487Z
- Description: Alles zur Fußball-WM 2026 in Kanada, Mexiko und den USA, vom 11. Juni bis 19. Juli: Spielplan der 104 Spiele, 48 Teams, 12 Gruppen, Prognosen und der DFB-Hub.

## Die WM wird 2026 anders.

### Spiele heute

### Nächste Spiele

### Letzte Ergebnisse

### Deutschlands Gruppenspiele

### Neueste Geschichten

#### Deutschland gewinnt die WM-Generalprobe in Chicago

#### Wem fehlt Deutschland am meisten? Die Ausfälle taktisch betrachtet

#### Die großen Streichungen: Gnabry, Füllkrug und Andrich fehlen

#### Lennart Karls WM-Aus — und was Ouédraogo dem DFB bringt

### Wer wird Weltmeister 2026 — und wo steht Deutschland?

### Wo anfangen

#### 104 Spiele, Tag für Tag

#### 12 Gruppen in Echtzeit

#### Alles zum DFB-Team

#### Alle 48 Teams

#### 16 Stadien, drei Länder

#### Alle Spiele in deutscher Zeit

### Alles, um die WM von hier aus zu verfolgen

#### Alle 104 Spiele in MESZ

#### Wo läuft die WM 2026?

#### Wer wird Weltmeister?

#### Der unterschätzte Faktor

#### Das Eröffnungsspiel

#### Das Finale

### In Zahlen

### Was alle zur WM 2026 fragen

### Tor-Benachrichtigungen, in Echtzeit.

#### Frühstück mit der WM

## Page Text

· 48 Teams · 12 Gruppen · 104 Spiele

Kanada, Mexiko und die USA teilen sich 16 Städte und 104 Spiele in fünf Wochen. Die größte WM aller Zeiten, erstmals mit 48 Teams. Komplette Berichterstattung — mit Fokus auf die Mannschaft.

K.-o.-Phase beginnt — 32 Mannschaften

MetLife Stadium, New Jersey · 19. Juli

EndeSpanien 4-0 Saudi-Arabien

VorschauUruguayvsKap Verde

VorschauNeuseelandvsÄgypten

VorschauArgentinienvsÖsterreich

BerichtSpanien4–0Saudi-Arabien

BerichtDeutschland2–1Elfenbeinküste

Weißt du alles über die WM 2026?

8 neue Fragen jeden Tag. Baue deine Serie aus und fordere deine Freunde heraus.

Die Mannschaft · Gruppe E

Spieltag 2 · Philadelphia

Deutschland · 6. Juni 2026 Deutschland gewinnt die WM-Generalprobe in Chicago

Deutschland · 6. Juni 2026

Deutschland · 6. Juni 2026 Wem fehlt Deutschland am meisten? Die Ausfälle taktisch betrachtet

Deutschland · 6. Juni 2026 Die großen Streichungen: Gnabry, Füllkrug und Andrich fehlen

Deutschland · 6. Juni 2026 Lennart Karls WM-Aus — und was Ouédraogo dem DFB bringt

Spanien ist unser Favorit, Brasilien der Value-Tipp. Doch Deutschland hat unter Nagelsmann echtes Titel-Upside — bei einer Quote von 11,00 womöglich der beste Wert im ganzen Feld. Unsere komplette Analyse der Anwärter.

Deutschland bei der WM 2026: Nagelsmanns Reset12 Min · Analyse

Hitze bei der WM: der unterschätzte Faktor9 Min

Alle Anstoßzeiten in deutscher ZeitÜbersicht

Filtern nach Datum, Gruppe, Team oder Stadion. Deutsche Zeit automatisch.

Aktualisiert nach jedem Abpfiff, mit erklärten Tiebreaker-Regeln.

Kader, Spielplan der Gruppe E, Nagelsmanns Taktik, Prognosen.

Kader, Trainer, WM-Historie und der Schlüsselspieler jedes Teams.

Vom MetLife Stadium bis zur Höhe von Mexiko-Stadt.

Nach Tageszeit sortiert — welche Spiele du in der Prime Time siehst.

Anstoßzeiten in deutscher Zeit, Übertragung im Free-TV und auf MagentaTV, Prognosen und der Hitzefaktor. Ehrlich und ohne Umschweife.

Nach Tageszeit sortiert — welche Spiele in der Prime Time laufen und welche tief in der Nacht.

ARD und ZDF zeigen die großen Spiele im Free-TV, MagentaTV überträgt alle 104 Partien.

Spanien ist Favorit, Brasilien der Value-Tipp — und Deutschland hat echtes Titel-Upside.

Mittagsspiele bei über 30 Grad: Wie die Hitze über Erfolg und Misserfolg entscheiden kann.

Mexiko gegen Südafrika im Aztekenstadion — 03:00 Uhr MESZ in der Nacht.

MetLife Stadium bei New York — das größte Stadion des Turniers, mit rund 82.500 Plätzen.

Im Vergleich zu Katar 2022: 16 Teams mehr, 40 Spiele mehr, 11 Tage länger.

Termine, Gastgeber, Format. Kurz und ohne Umschweife.

Die WM 2026 wird gemeinsam von drei Ländern ausgerichtet: Kanada, Mexiko und den USA. 16 Gastgeberstädte, 11 Stadien in den USA, 3 in Mexiko, 2 in Kanada.

Die WM 2026 startet am 11. Juni 2026 mit dem Eröffnungsspiel im Aztekenstadion in Mexiko-Stadt. Das Finale steigt am 19. Juli 2026 im MetLife Stadium bei New York.

Deutschland spielt in Gruppe E gegen Ecuador, Côte d’Ivoire und WM-Debütant Curaçao. Das schwerste Spiel ist Ecuador zum Auftakt am 17. Juni in Seattle.

Die WM 2026 ist die erste mit 48 Mannschaften — 16 mehr als in Katar 2022. Sie sind in 12 Vierergruppen aufgeteilt, mit 104 Spielen statt bisher 64.

Julian Nagelsmann, seit September 2023 im Amt. Es ist sein erstes WM-Turnier als Bundestrainer. Schlüsselspieler sind Florian Wirtz, Jamal Musiala und Kai Havertz.

Spieltag 1 gegen Ecuador am 17. Juni um 03:00 Uhr MESZ (Nacht, Seattle). Die Spiele 2 und 3 jeweils um 22:00 Uhr MESZ — beste Sendezeit. Alle Zeiten auf unserer Seite Anstoßzeiten.

Wähle deine Teams und erhalte Tore, Abpfiffe und Ergebnisse direkt aufs Handy oder den Desktop. Keine App, kein Konto.

Wir verwenden keine Tracking-Cookies und geben keine Daten an Dritte weiter. Nur technische Speicherung für Einstellungen (Dark Mode, Favoriten). Anonyme Analytics über Cloudflare.

Installiere WM26 auf dem Handy

Sofortiger Zugriff, ohne Browser und mit Tor-Benachrichtigungen.

Tägliche Zusammenfassung um 7:00 Uhr: die Spiele des Tages, das letzte Ergebnis, ein redaktioneller Beitrag. Kein Spam, kein Griff zum Handy mitten in der Arbeit.

Abbestellen mit einem Klick. Wir geben deine E-Mail an niemanden weiter.

Erhalten. Prüfe deine E-Mails zur Bestätigung.

Berichterstattung zur WM 2026 in anderen Märkten

🇵🇹 Portugal mundial2026.com.pt →

🇪🇸 España copamundialdefutbol.es →

🇵🇪 Perú mundial2026.pe →

Unabhängige Berichterstattung zur FIFA WM 2026. Spielplan, Tabellen, Profile und taktische Analysen.

© 2026 WM26. Unabhängiges redaktionelles Projekt.

## Images

- Offizielles WM-2026-Emblem: assets/images/001-offizielles-wm-2026-emblem.svg
- Image: assets/images/002-image.png
- Image: assets/images/003-image.png
- Image: assets/images/004-image.png
- Image: assets/images/005-image.png
- Open Graph image: assets/images/010-open-graph-image.bin